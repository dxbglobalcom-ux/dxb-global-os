set -a; for f in ./.env ./.env.local ./.env.daemon; do [ -f "$f" ] && source "$f"; done; set +a
export DXB_DATABASE_URL="postgresql://postgres:postgres@127.0.0.1:54422/postgres"; unset DXB_COMPANY_DATABASE_URL
trace="$1"; shift
exec strace -ff -qq -y -s 512 -e trace=openat,open,creat,execve,clone,clone3,fork,vfork,chdir,fchdir,mkdir,mkdirat,unlink,unlinkat,rmdir,rename,renameat,renameat2,link,linkat,symlink,symlinkat -o "$trace" "$@"
